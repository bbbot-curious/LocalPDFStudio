# LocalPDF Studio v2.0 (100% Offline Browser PDF Editor)

An offline-first, client-side PDF studio built with `pdf-lib`, `pdfjs-dist`, `tesseract.js`, `JSZip`, and Vite. Designed for zero network egress, strict decompression & recursion safety, true redaction with verification, AcroForms management, batch workers, and local OCR.

## Included Modules
- **Part 4 — Page Management & Document Worker (`src/workers/documentWorker.js`, `src/pdf/pageManager.js`)**:
  - Merge PDFs with `/AcroForm` field name collision deduplication and encrypted/owner-restricted error reporting.
  - Split PDFs by page ranges (`1-3, 5, 8-12`), every `N` pages, or outline/bookmark top-level page indices.
  - Rotate (`/Rotate = (current + delta) % 360`), extract, delete, and deep-duplicate pages without re-rendering raster pixels.
  - Bounded batch operations (batch rotate, batch watermark, batch metadata scrub, batch OCR) with per-file status, error isolation, and cancellation (`AbortController` / cancellation flag).
  - Undo/Redo command stack with `Ctrl/Cmd+Z` and `Ctrl/Cmd+Y` shortcuts.
- **Part 5 — PDF Security & Hardening (`src/pdf/securityGuard.js`, `index.html`)**:
  - Decompression bomb & resource limits (max page count, max single-page pixel cap `16384×16384`, stream decompression byte cap, recursion depth & `visitedSet` cycle guard, and worker timeout + respawn).
  - Strict Content Security Policy (`connect-src 'none'`, `object-src 'none'`, `frame-ancestors 'none'`).
  - Safe DOM rendering (`textContent` / safe element creation; no `innerHTML` with untrusted PDF strings) and "Clear Session & Wipe Local Cache" memory/OPFS/Cache cleanup.
- **Part 6 — True Redaction & Verification Gate (`src/pdf/redactionEngine.js`)**:
  - Permanently removes or clips intersecting text operators (`Tj`, `TJ`, `'`, `"`), rasterizes/erases affected pixel regions onto a fresh raster layer, removes intersecting vector path operators, scrubs `/Info` & `/Metadata` XMP streams, removes hidden `/OCProperties` Optional Content Groups, and runs a post-redaction verification pass (`pdfjs-dist` text check + visual preview render).
- **Part 7 — AcroForms Engine (`src/pdf/formsEngine.js`)**:
  - Inspects `/AcroForm` fields and creates/edits text, checkbox, radio, dropdown/combo, list, and signature fields with `/AP` appearance streams, required/read-only flags, validation rules (required, regex, min/max, numeric/date), XFDF/FDF/JSON/CSV import/export, and form flattening.
- **Part 8 — 100% Offline OCR Engine (`src/pdf/ocrEngine.js`, `src/workers/imageWorker.js`)**:
  - Configured with local relative paths under `./ocr/` (`workerPath`, `corePath`, `langPath`) with zero CDN fallback, local `.traineddata` pack installation via file picker, Web Worker grayscale + contrast normalization preprocessing, and invisible text layer generation (`3 Tr` rendering mode) aligned to page coordinates, with progress, pause/resume, and cancel support.

## Offline Asset Setup
1. Place `.traineddata` files (e.g. `eng.traineddata`, `ind.traineddata`) and local Tesseract worker/core assets in `public/ocr/`.
2. Optionally place local `.ttf` font subsets in `public/fonts/`.
