import { PDFName, PDFString, PDFHexString, PDFStream } from 'pdf-lib';
import { hexToRgbNormalized } from './textEngine.js';

function encodeUtf16BeHex(str = '') {
  const bytes = new Uint8Array(2 + str.length * 2);
  bytes[0] = 0xfe; bytes[1] = 0xff;
  for (let i = 0; i < str.length; i++) {
    const code = str.charCodeAt(i);
    bytes[2 + i * 2] = (code >> 8) & 0xff;
    bytes[2 + i * 2 + 1] = code & 0xff;
  }
  return PDFHexString.of(Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join(''));
}

export function appendSpecCompliantAnnotation(pdfDoc, pageIndex, spec) {
  const page = pdfDoc.getPage(pageIndex);
  const context = pdfDoc.context;
  const { subtype, rect, contents = '', colorHex = '#FACC15', strokeWidth = 2, arrowHead = false, pointsPt = [], stampLabel = 'REVIEWED' } = spec;
  const { r, g, b } = hexToRgbNormalized(colorHex);
  const x1 = Math.min(rect.x1, rect.x2), y1 = Math.min(rect.y1, rect.y2);
  const x2 = Math.max(rect.x1, rect.x2), y2 = Math.max(rect.y1, rect.y2);
  const w = Math.max(4, x2 - x1), h = Math.max(4, y2 - y1);
  const local = pointsPt.map((p) => ({ x: p.x - x1, y: p.y - y1 }));

  const ops = ['q'];
  if (subtype === 'Highlight') ops.push(`${r} ${g} ${b} rg`, `0 0 ${w} ${h} re f`);
  else if (subtype === 'Underline') ops.push(`${r} ${g} ${b} RG`, `${strokeWidth} w`, `0 1.5 m ${w} 1.5 l S`);
  else if (subtype === 'StrikeOut') ops.push(`${r} ${g} ${b} RG`, `${strokeWidth} w`, `0 ${h * 0.5} m ${w} ${h * 0.5} l S`);
  else if (subtype === 'Square') ops.push(`${r} ${g} ${b} RG`, `${strokeWidth} w`, `1 1 ${Math.max(1, w - 2)} ${Math.max(1, h - 2)} re S`);
  else if (subtype === 'Circle') {
    const cx = w / 2, cy = h / 2, rx = Math.max(1, w / 2 - 1), ry = Math.max(1, h / 2 - 1), k = 0.5522847498;
    ops.push(`${r} ${g} ${b} RG`, `${strokeWidth} w`, `${cx + rx} ${cy} m`, `${cx + rx} ${cy + ry * k} ${cx + rx * k} ${cy + ry} ${cx} ${cy + ry} c`, `${cx - rx * k} ${cy + ry} ${cx - rx} ${cy + ry * k} ${cx - rx} ${cy} c`, `${cx - rx} ${cy - ry * k} ${cx - rx * k} ${cy - ry} ${cx} ${cy - ry} c`, `${cx + rx * k} ${cy - ry} ${cx + rx} ${cy - ry * k} ${cx + rx} ${cy} c`, 'S');
  } else if (subtype === 'Line') {
    const p0 = local[0] || { x: 2, y: 2 }, p1 = local[local.length - 1] || { x: w - 2, y: h - 2 };
    ops.push(`${r} ${g} ${b} RG`, `${strokeWidth} w`, `${p0.x} ${p0.y} m ${p1.x} ${p1.y} l S`);
    if (arrowHead) {
      const ang = Math.atan2(p1.y - p0.y, p1.x - p0.x), len = Math.max(9, strokeWidth * 4), spr = Math.PI / 6;
      ops.push(`${r} ${g} ${b} rg`, `${p1.x} ${p1.y} m ${p1.x - len * Math.cos(ang - spr)} ${p1.y - len * Math.sin(ang - spr)} l ${p1.x - len * Math.cos(ang + spr)} ${p1.y - len * Math.sin(ang + spr)} l h f`);
    }
  } else if ((subtype === 'PolyLine' || subtype === 'Ink') && local.length >= 2) {
    ops.push(`${r} ${g} ${b} RG`, `${strokeWidth} w`, '1 J 1 j', `${local[0].x} ${local[0].y} m`);
    for (let i = 1; i < local.length; i++) ops.push(`${local[i].x} ${local[i].y} l`);
    ops.push('S');
  } else if (subtype === 'Text') {
    ops.push(`${r} ${g} ${b} rg`, '0.2 0.2 0.2 RG 1 w', `1 1 ${Math.max(10, w - 2)} ${Math.max(10, h - 2)} re B`);
  } else if (subtype === 'FreeText') {
    ops.push('1 1 0.94 rg', `${r} ${g} ${b} RG 1.5 w`, `${w * 0.25} 2 ${Math.max(10, w * 0.72)} ${Math.max(10, h - 4)} re B`, `2 2 m ${w * 0.25} ${h * 0.5} l S`);
  } else if (subtype === 'Stamp') {
    const label = stampLabel.replace(/[()\\]/g, '');
    ops.push(`${r} ${g} ${b} RG 2 w`, `2 2 ${Math.max(12, w - 4)} ${Math.max(12, h - 4)} re S`, 'BT', '/F1 10 Tf', `${r} ${g} ${b} rg`, `6 ${Math.max(5, h * 0.35)} Td`, `(${label}) Tj`, 'ET');
  }
  ops.push('Q');

  const apStream = PDFStream.of(
    context.obj({
      Type: 'XObject',
      Subtype: 'Form',
      FormType: 1,
      BBox: [0, 0, w, h],
      Resources: subtype === 'Stamp' ? { Font: { F1: { Type: 'Font', Subtype: 'Type1', BaseFont: 'Helvetica-Bold' } } } : {}
    }),
    new TextEncoder().encode(ops.join('\n'))
  );
  const apRef = context.register(apStream);

  const dict = {
    Type: 'Annot',
    Subtype: subtype,
    Rect: [x1, y1, x2, y2],
    Contents: encodeUtf16BeHex(contents),
    C: [r, g, b],
    F: 4,
    AP: { N: apRef }
  };
  if (subtype === 'FreeText') dict.DA = PDFString.of(`/Helv 11 Tf ${r} ${g} ${b} rg`);

  const ref = context.register(context.obj(dict));
  let annots = page.node.lookup(PDFName.of('Annots'));
  if (!annots) {
    annots = context.obj([]);
    page.node.set(PDFName.of('Annots'), annots);
  }
  annots.push(ref);
}
