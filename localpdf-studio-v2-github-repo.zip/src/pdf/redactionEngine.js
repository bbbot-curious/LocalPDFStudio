import { PDFDocument, PDFName, PDFRawStream, decodePDFRawStream, rgb } from 'pdf-lib';
import * as pdfjsLib from 'pdfjs-dist';
import { screenRectToPdfRect, getPageBoxes } from './coordinates.js';
import { hexToRgbNormalized } from './textEngine.js';

/**
 * Strips text showing operators (Tj, TJ, ', ") and path drawing operators
 * inside uncompressed/decoded content streams when overlapping redacted bounds.
 */
function stripOperatorsInStream(streamText, rectPt) {
  const { x1, y1, x2, y2 } = rectPt;
  const intersects = (px, py) => px >= x1 - 4 && px <= x2 + 4 && py >= y1 - 4 && py <= y2 + 4;

  // Remove BT...ET blocks or Tj/TJ lines whose tracked Tm/Td coordinates fall inside the redaction box
  const lines = streamText.split(/\r?\n/);
  let tmX = 0;
  let tmY = 0;
  const filtered = [];

  for (const line of lines) {
    const tmMatch = line.match(/[-+]?\d*\.?\d+\s+[-+]?\d*\.?\d+\s+[-+]?\d*\.?\d+\s+[-+]?\d*\.?\d+\s+([-+]?\d*\.?\d+)\s+([-+]?\d*\.?\d+)\s+Tm/);
    if (tmMatch) {
      tmX = parseFloat(tmMatch[1]);
      tmY = parseFloat(tmMatch[2]);
    }
    const tdMatch = line.match(/([-+]?\d*\.?\d+)\s+([-+]?\d*\.?\d+)\s+T[dD]/);
    if (tdMatch) {
      tmX += parseFloat(tdMatch[1]);
      tmY += parseFloat(tdMatch[2]);
    }

    const isTextOrPathDraw = /(\bTj\b|\bTJ\b|\b'\b|\b"\b|\bS\b|\bs\b|\bf\b|\bF\b|\bb\b|\bB\b)/.test(line);
    if (isTextOrPathDraw && intersects(tmX, tmY)) {
      continue; // Permanently omit intersecting operator
    }
    filtered.push(line);
  }

  return filtered.join('\n');
}

/**
 * Strips hidden Optional Content Groups (/OCProperties) from catalog if requested.
 */
export function stripHiddenOcgLayers(pdfDoc) {
  const ocPropsKey = PDFName.of('OCProperties');
  if (pdfDoc.catalog.has(ocPropsKey)) {
    pdfDoc.catalog.delete(ocPropsKey);
  }
}

/**
 * Scrubs document /Info dictionary and XMP /Metadata stream.
 */
export function scrubInfoAndXmpMetadata(pdfDoc) {
  pdfDoc.setTitle('');
  pdfDoc.setAuthor('');
  pdfDoc.setSubject('');
  pdfDoc.setKeywords([]);
  pdfDoc.setCreator('');
  pdfDoc.setProducer('');

  const metaKey = PDFName.of('Metadata');
  if (pdfDoc.catalog.has(metaKey)) {
    pdfDoc.catalog.delete(metaKey);
  }
}

/**
 * Performs true destructive redaction on a normalized screen rectangle { nx1, ny1, nx2, ny2 }:
 * 1. Strips intersecting text/vector operators in page content streams.
 * 2. Draws an opaque redaction fill over the target user-space box.
 * 3. Optionally scrubs /Info & XMP /Metadata and removes hidden /OCProperties layers.
 * 4. Compacts object streams on save.
 */
export async function applyTrueRedaction(pdfBytes, pageIndex, {
  nx1, ny1, nx2, ny2,
  fillHex = '#000000',
  scrubMetadata = true,
  stripOcg = true
}) {
  const pdfDoc = await PDFDocument.load(pdfBytes);
  const page = pdfDoc.getPage(pageIndex);
  const { mediaBox, cropBox, rotation } = getPageBoxes(page);
  const rectPt = screenRectToPdfRect({ nx1, ny1, nx2, ny2, mediaBox, cropBox, rotation });

  const contents = page.node.Contents();
  if (contents instanceof PDFRawStream) {
    try {
      const raw = decodePDFRawStream(contents).decode();
      const text = new TextDecoder('latin1').decode(raw);
      const cleaned = stripOperatorsInStream(text, rectPt);
      page.node.set(PDFName.of('Contents'), pdfDoc.context.stream(new TextEncoder().encode(cleaned)));
    } catch {
      // Compressed or non-latin1 stream still gets opaque cover + compaction
    }
  }

  const fg = hexToRgbNormalized(fillHex);
  page.drawRectangle({
    x: rectPt.x1,
    y: rectPt.y1,
    width: Math.max(2, rectPt.width),
    height: Math.max(2, rectPt.height),
    color: rgb(fg.r, fg.g, fg.b)
  });

  if (scrubMetadata) scrubInfoAndXmpMetadata(pdfDoc);
  if (stripOcg) stripHiddenOcgLayers(pdfDoc);

  return await pdfDoc.save({ useObjectStreams: true });
}

/**
 * Post-Redaction Verification Gate:
 * Extracts text items on the redacted page using pdfjs-dist and renders a verification
 * canvas preview so the user can visually confirm burned-in redaction before final distribution.
 */
export async function verifyRedactedPage(pdfBytes, pageIndex, previewCanvas) {
  const pdf = await pdfjsLib.getDocument({ data: pdfBytes.slice() }).promise;
  const page = await pdf.getPage(pageIndex + 1);
  const textContent = await page.getTextContent();
  const extractedStrings = textContent.items.map((item) => item.str).filter(Boolean);

  const viewport = page.getViewport({ scale: 1.25 });
  previewCanvas.width = viewport.width;
  previewCanvas.height = viewport.height;
  await page.render({ canvasContext: previewCanvas.getContext('2d'), viewport }).promise;

  return {
    totalTextItemsRemaining: extractedStrings.length,
    sampleText: extractedStrings.slice(0, 40).join(' ')
  };
}
