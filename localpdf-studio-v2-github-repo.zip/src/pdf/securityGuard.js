import { PDFName, PDFDict, PDFArray } from 'pdf-lib';

export const SECURITY_LIMITS = {
  MAX_PAGES: 1000,
  MAX_SINGLE_PAGE_DIM_PX: 16384,
  MAX_DECOMPRESSED_STREAM_BYTES: 128 * 1024 * 1024, // 128 MB per stream cap
  MAX_TREE_DEPTH: 256,
  WORKER_TIMEOUT_MS: 45000
};

/**
 * Validates PDF header, page count, and detects encryption/owner restrictions
 * before allocating large buffers or rendering.
 */
export function preflightPdfSecurity(bytes) {
  if (!(bytes instanceof Uint8Array) || bytes.byteLength < 8) {
    throw new Error('Invalid or empty PDF buffer.');
  }
  const header = new TextDecoder('latin1').decode(bytes.subarray(0, 1024));
  if (!header.includes('%PDF-')) {
    throw new Error('Missing %PDF- header signature.');
  }
  const isEncrypted = /\/Encrypt/.test(header) || new TextDecoder('latin1').decode(bytes).includes('/Encrypt');
  return { isEncrypted };
}

/**
 * Traverses /Page tree safely with cycle detection (visitedSet) and depth cap
 * to prevent infinite recursion on malformed or adversarial PDFs.
 */
export function auditPageTreeSafety(pdfDoc) {
  const pageCount = pdfDoc.getPageCount();
  if (pageCount > SECURITY_LIMITS.MAX_PAGES) {
    throw new Error(`Page count (${pageCount}) exceeds safety cap (${SECURITY_LIMITS.MAX_PAGES}).`);
  }

  const visited = new Set();
  function walk(node, depth = 0) {
    if (depth > SECURITY_LIMITS.MAX_TREE_DEPTH) {
      throw new Error('Malformed PDF: /Page tree depth exceeded safety limit.');
    }
    const refKey = node?.toString?.() || `depth-${depth}`;
    if (visited.has(refKey)) {
      throw new Error('Malformed PDF: circular /Page tree reference detected.');
    }
    visited.add(refKey);
    if (node instanceof PDFDict) {
      const kids = node.lookup(PDFName.of('Kids'));
      if (kids instanceof PDFArray) {
        for (let i = 0; i < kids.size(); i++) {
          walk(kids.lookup(i), depth + 1);
        }
      }
    }
  }

  walk(pdfDoc.catalog.lookup(PDFName.of('Pages')), 0);

  for (let i = 0; i < pageCount; i++) {
    const page = pdfDoc.getPage(i);
    const { width, height } = page.getSize();
    const pxW = Math.round((width / 72) * 150);
    const pxH = Math.round((height / 72) * 150);
    if (pxW > SECURITY_LIMITS.MAX_SINGLE_PAGE_DIM_PX || pxH > SECURITY_LIMITS.MAX_SINGLE_PAGE_DIM_PX) {
      throw new Error(`Page ${i + 1} exceeds max single-page dimension cap (${SECURITY_LIMITS.MAX_SINGLE_PAGE_DIM_PX}px).`);
    }
  }

  return { pageCount, safe: true };
}

/**
 * Wipes in-memory buffers, Cache Storage, and OPFS temporary files when user clicks "Wipe Session".
 */
export async function wipeLocalSessionStorage() {
  try {
    if ('caches' in window) {
      const keys = await caches.keys();
      await Promise.all(keys.map((k) => caches.delete(k)));
    }
  } catch {
    // Ignore storage errors
  }

  try {
    if (navigator.storage && typeof navigator.storage.getDirectory === 'function') {
      const root = await navigator.storage.getDirectory();
      for await (const [name] of root.entries()) {
        await root.removeEntry(name, { recursive: true });
      }
    }
  } catch {
    // OPFS may not be supported or active
  }
}
