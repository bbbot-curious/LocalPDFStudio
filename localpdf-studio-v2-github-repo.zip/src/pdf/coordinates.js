export function screenToPdfUserSpace({ nx, ny, mediaBox, cropBox = null, rotation = 0 }) {
  const box = cropBox || mediaBox;
  const [x1, y1, x2, y2] = box;
  const cropW = x2 - x1;
  const cropH = y2 - y1;
  const rot = ((rotation % 360) + 360) % 360;
  let ux = 0, uyFromBottom = 0;
  if (rot === 0) { ux = nx * cropW; uyFromBottom = (1 - ny) * cropH; }
  else if (rot === 90) { ux = ny * cropW; uyFromBottom = nx * cropH; }
  else if (rot === 180) { ux = (1 - nx) * cropW; uyFromBottom = ny * cropH; }
  else if (rot === 270) { ux = (1 - ny) * cropW; uyFromBottom = (1 - nx) * cropH; }
  else throw new Error(`Unsupported /Rotate value: ${rotation}`);
  return { x: x1 + ux, y: y1 + uyFromBottom };
}

export function screenRectToPdfRect({ nx1, ny1, nx2, ny2, mediaBox, cropBox = null, rotation = 0 }) {
  const p1 = screenToPdfUserSpace({ nx: nx1, ny: ny1, mediaBox, cropBox, rotation });
  const p2 = screenToPdfUserSpace({ nx: nx2, ny: ny2, mediaBox, cropBox, rotation });
  return {
    x1: Math.min(p1.x, p2.x),
    y1: Math.min(p1.y, p2.y),
    x2: Math.max(p1.x, p2.x),
    y2: Math.max(p1.y, p2.y),
    width: Math.abs(p2.x - p1.x),
    height: Math.abs(p2.y - p1.y)
  };
}

export function getPageBoxes(page) {
  const mb = page.getMediaBox();
  const cb = page.getCropBox();
  return {
    mediaBox: [mb.x, mb.y, mb.x + mb.width, mb.y + mb.height],
    cropBox: [cb.x, cb.y, cb.x + cb.width, cb.y + cb.height],
    rotation: page.getRotation().angle || 0
  };
}
