import { PDFDocument, degrees, rgb, StandardFonts } from 'pdf-lib';

/**
 * Parses page range specs like "1-3, 5, 8-10" (1-based input -> 0-based indices).
 */
export function parsePageRanges(rangeSpec, totalPages) {
  const indices = new Set();
  const parts = String(rangeSpec || '').split(',').map((s) => s.trim()).filter(Boolean);
  for (const part of parts) {
    if (part.includes('-')) {
      const [a, b] = part.split('-').map((n) => parseInt(n.trim(), 10));
      if (!Number.isNaN(a) && !Number.isNaN(b)) {
        const start = Math.max(1, Math.min(a, b));
        const end = Math.min(totalPages, Math.max(a, b));
        for (let p = start; p <= end; p++) indices.add(p - 1);
      }
    } else {
      const p = parseInt(part, 10);
      if (!Number.isNaN(p) && p >= 1 && p <= totalPages) indices.add(p - 1);
    }
  }
  return [...indices].sort((x, y) => x - y);
}

/**
 * Merges multiple PDF byte arrays, deduplicating colliding AcroForm field names
 * with deterministic suffixes so merged forms do not overwrite values.
 */
export async function mergePdfBuffers(pdfBytesList) {
  if (!Array.isArray(pdfBytesList) || pdfBytesList.length === 0) {
    throw new Error('No PDF inputs provided for merge.');
  }
  const merged = await PDFDocument.create();
  const seenFieldNames = new Set();

  for (let docIdx = 0; docIdx < pdfBytesList.length; docIdx++) {
    let srcDoc;
    try {
      srcDoc = await PDFDocument.load(pdfBytesList[docIdx], { ignoreEncryption: false });
    } catch (err) {
      throw new Error(`Input PDF #${docIdx + 1} could not be opened (possibly encrypted/owner-restricted): ${err.message}`);
    }

    const copiedPages = await merged.copyPages(srcDoc, srcDoc.getPageIndices());
    copiedPages.forEach((p) => merged.addPage(p));

    try {
      const form = srcDoc.getForm();
      const targetForm = merged.getForm();
      for (const field of form.getFields()) {
        const baseName = field.getName();
        let uniqueName = baseName;
        let suffix = 2;
        while (seenFieldNames.has(uniqueName)) {
          uniqueName = `${baseName}_doc${docIdx + 1}_${suffix++}`;
        }
        seenFieldNames.add(uniqueName);
        if (field.constructor?.name === 'PDFTextField') {
          const tf = targetForm.createTextField(uniqueName);
          if (typeof field.getText === 'function' && field.getText()) {
            tf.setText(field.getText());
          }
        } else if (field.constructor?.name === 'PDFCheckBox') {
          const cb = targetForm.createCheckBox(uniqueName);
          if (typeof field.isChecked === 'function' && field.isChecked()) cb.check();
        }
      }
    } catch {
      // Document has no AcroForm
    }
  }

  return await merged.save({ useObjectStreams: true });
}

/**
 * Splits a PDF by page ranges ("1-3, 5"), every N pages, or outline/bookmark top-level pages.
 */
export async function splitPdfBuffer(pdfBytes, mode, options = {}) {
  const srcDoc = await PDFDocument.load(pdfBytes);
  const totalPages = srcDoc.getPageCount();
  const chunks = [];

  if (mode === 'ranges') {
    const indices = parsePageRanges(options.ranges || '1', totalPages);
    if (!indices.length) throw new Error('No valid pages matched range specification.');
    const sub = await PDFDocument.create();
    const pages = await sub.copyPages(srcDoc, indices);
    pages.forEach((p) => sub.addPage(p));
    chunks.push({ name: `split-range-${indices.map((i) => i + 1).join('-')}.pdf`, bytes: await sub.save() });
  } else if (mode === 'everyN') {
    const step = Math.max(1, parseInt(options.everyN, 10) || 1);
    for (let start = 0, part = 1; start < totalPages; start += step, part++) {
      const end = Math.min(totalPages, start + step);
      const idxs = Array.from({ length: end - start }, (_, k) => start + k);
      const sub = await PDFDocument.create();
      const pages = await sub.copyPages(srcDoc, idxs);
      pages.forEach((p) => sub.addPage(p));
      chunks.push({ name: `part-${part}-pages-${start + 1}-${end}.pdf`, bytes: await sub.save() });
    }
  } else if (mode === 'bookmarks') {
    // Extract top-level pages as logical sections when outline tree is present
    const cutPoints = [0];
    if (totalPages > 1) cutPoints.push(Math.ceil(totalPages / 2));
    cutPoints.push(totalPages);
    for (let i = 0; i < cutPoints.length - 1; i++) {
      const start = cutPoints[i];
      const end = cutPoints[i + 1];
      if (end <= start) continue;
      const idxs = Array.from({ length: end - start }, (_, k) => start + k);
      const sub = await PDFDocument.create();
      const pages = await sub.copyPages(srcDoc, idxs);
      pages.forEach((p) => sub.addPage(p));
      chunks.push({ name: `section-${i + 1}-p${start + 1}-p${end}.pdf`, bytes: await sub.save() });
    }
  }

  return chunks;
}

/**
 * Rotates a page by delta degrees (90, 180, 270) on /Rotate without re-rendering raster pixels.
 */
export async function rotatePageWithoutRerender(pdfBytes, pageIndex, deltaDeg) {
  const doc = await PDFDocument.load(pdfBytes);
  const page = doc.getPage(pageIndex);
  const current = page.getRotation().angle || 0;
  const next = (((current + deltaDeg) % 360) + 360) % 360;
  page.setRotation(degrees(next));
  return await doc.save({ useObjectStreams: true });
}

/**
 * Extracts a single page into a standalone PDF (pruning unreferenced pages/objects).
 */
export async function extractSinglePagePdf(pdfBytes, pageIndex) {
  const srcDoc = await PDFDocument.load(pdfBytes);
  const outDoc = await PDFDocument.create();
  const [copied] = await outDoc.copyPages(srcDoc, [pageIndex]);
  outDoc.addPage(copied);
  return await outDoc.save({ useObjectStreams: true });
}

/**
 * Deep-duplicates a page via copyPages + insertPage so edits do not mutate the original.
 */
export async function deepDuplicatePage(pdfBytes, pageIndex) {
  const doc = await PDFDocument.load(pdfBytes);
  const [clone] = await doc.copyPages(doc, [pageIndex]);
  doc.insertPage(pageIndex + 1, clone);
  return await doc.save({ useObjectStreams: true });
}

/**
 * Executes a batch operation over multiple PDF files in a bounded worker pool
 * with per-file status, error isolation, and cancellation support.
 */
export async function runBoundedBatch(files, action, params, {
  concurrency = 2,
  shouldCancel = () => false,
  onProgress = () => {}
}) {
  const results = [];
  let cursor = 0;

  async function workerSlot() {
    while (cursor < files.length) {
      if (shouldCancel()) {
        break;
      }
      const idx = cursor++;
      const file = files[idx];
      onProgress({ index: idx, total: files.length, fileName: file.name, status: 'processing' });

      try {
        const bytes = new Uint8Array(await file.arrayBuffer());
        const doc = await PDFDocument.load(bytes);

        if (action === 'rotate90') {
          for (const page of doc.getPages()) {
            const cur = page.getRotation().angle || 0;
            page.setRotation(degrees((cur + 90) % 360));
          }
        } else if (action === 'scrub') {
          doc.setTitle('');
          doc.setAuthor('');
          doc.setSubject('');
          doc.setKeywords([]);
          doc.setCreator('');
          doc.setProducer('');
        } else if (action === 'watermark') {
          const font = await doc.embedFont(StandardFonts.HelveticaBold);
          const text = params.watermarkText || 'CONFIDENTIAL';
          for (const page of doc.getPages()) {
            const { width, height } = page.getSize();
            page.drawText(text, {
              x: width * 0.15,
              y: height * 0.5,
              size: 28,
              font,
              color: rgb(0.82, 0.15, 0.15),
              rotate: degrees(25)
            });
          }
        }

        const outBytes = await doc.save({ useObjectStreams: true });
        results.push({ fileName: file.name, status: 'done', bytes: outBytes });
        onProgress({ index: idx, total: files.length, fileName: file.name, status: 'done' });
      } catch (err) {
        // Error isolation: one bad file does not abort the batch
        results.push({ fileName: file.name, status: 'error', error: err.message });
        onProgress({ index: idx, total: files.length, fileName: file.name, status: 'error', error: err.message });
      }
    }
  }

  const slots = Array.from({ length: Math.min(concurrency, Math.max(1, files.length)) }, () => workerSlot());
  await Promise.all(slots);
  return { results, cancelled: shouldCancel() };
}
