import { PDFDocument, rgb, StandardFonts, PDFName } from 'pdf-lib';
import { screenRectToPdfRect, getPageBoxes } from './coordinates.js';
import { hexToRgbNormalized } from './textEngine.js';

/**
 * Adds a new AcroForm field (text, checkbox, radio, dropdown, listbox, or signature box)
 * with required/read-only flags, custom regex/range metadata in field tooltip (/TU),
 * and visible appearance.
 */
export async function createAcroFormField(pdfDoc, pageIndex, spec) {
  const {
    fieldType = 'text',
    name = 'field_1',
    value = '',
    options = ['Option A', 'Option B'],
    required = false,
    readOnly = false,
    regexPattern = '',
    rectNorm,
    colorHex = '#1e293b'
  } = spec;

  const page = pdfDoc.getPage(pageIndex);
  const { mediaBox, cropBox, rotation } = getPageBoxes(page);
  const rectPt = screenRectToPdfRect({ ...rectNorm, mediaBox, cropBox, rotation });
  const form = pdfDoc.getForm();
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const c = hexToRgbNormalized(colorHex);

  const opts = {
    x: rectPt.x1,
    y: rectPt.y1,
    width: Math.max(18, rectPt.width),
    height: Math.max(16, rectPt.height),
    borderWidth: 1,
    borderColor: rgb(c.r, c.g, c.b),
    backgroundColor: rgb(1, 1, 1)
  };

  let createdField = null;
  if (fieldType === 'text') {
    const tf = form.createTextField(name);
    if (value) tf.setText(value);
    tf.addToPage(page, { ...opts, font });
    createdField = tf;
  } else if (fieldType === 'checkbox') {
    const cb = form.createCheckBox(name);
    cb.addToPage(page, opts);
    if (['true', '1', 'yes', 'on'].includes(String(value).toLowerCase())) cb.check();
    createdField = cb;
  } else if (fieldType === 'radio') {
    const rg = form.createRadioGroup(name);
    const items = options.length ? options : ['Choice 1', 'Choice 2'];
    items.forEach((optLabel, i) => {
      rg.addOptionToPage(optLabel, page, {
        ...opts,
        y: Math.max(4, rectPt.y1 - i * (opts.height + 4))
      });
    });
    if (value && items.includes(value)) rg.select(value);
    createdField = rg;
  } else if (fieldType === 'dropdown') {
    const dd = form.createDropdown(name);
    const items = options.length ? options : ['Option A', 'Option B'];
    dd.addOptions(items);
    if (value && items.includes(value)) dd.select(value);
    dd.addToPage(page, { ...opts, font });
    createdField = dd;
  } else if (fieldType === 'listbox') {
    const lb = form.createOptionList(name);
    const items = options.length ? options : ['Item 1', 'Item 2'];
    lb.addOptions(items);
    if (value && items.includes(value)) lb.select(value);
    lb.addToPage(page, { ...opts, font });
    createdField = lb;
  } else if (fieldType === 'signature') {
    // Draw a dedicated signature field placeholder box + /TU metadata tag
    const sigTf = form.createTextField(`sig_${name}`);
    sigTf.setText(value || '[Sign Here]');
    sigTf.addToPage(page, {
      ...opts,
      font,
      backgroundColor: rgb(0.98, 0.99, 1)
    });
    sigTf.enableReadOnly();
    createdField = sigTf;
  }

  if (createdField) {
    if (required && typeof createdField.enableRequired === 'function') createdField.enableRequired();
    if (readOnly && typeof createdField.enableReadOnly === 'function') createdField.enableReadOnly();
    if (regexPattern && createdField.acroField?.dict) {
      createdField.acroField.dict.set(PDFName.of('TU'), pdfDoc.context.obj(`regex:${regexPattern}`));
    }
  }

  form.updateFieldAppearances(font);
  return name;
}

/**
 * Validates all AcroForm fields (required presence and optional regex constraint in /TU).
 */
export function validateAcroFormFields(pdfDoc) {
  const errors = [];
  let count = 0;
  try {
    const form = pdfDoc.getForm();
    const fields = form.getFields();
    count = fields.length;

    for (const field of fields) {
      const name = field.getName();
      const isReq = typeof field.isRequired === 'function' ? field.isRequired() : false;
      let val = '';
      if (typeof field.getText === 'function') val = field.getText() || '';
      else if (typeof field.isChecked === 'function') val = field.isChecked() ? 'true' : '';
      else if (typeof field.getSelected === 'function') val = (field.getSelected() || []).join(', ');

      if (isReq && !String(val).trim()) {
        errors.push(`Field "${name}" is required.`);
      }

      const tuObj = field.acroField?.dict?.lookup(PDFName.of('TU'));
      const tuStr = tuObj ? String(tuObj) : '';
      if (tuStr.includes('regex:') && String(val).trim()) {
        const pattern = tuStr.split('regex:')[1].replace(/[()]/g, '').trim();
        try {
          const rx = new RegExp(pattern);
          if (!rx.test(String(val))) {
            errors.push(`Field "${name}" value "${val}" does not match pattern /${pattern}/.`);
          }
        } catch {
          // Invalid regex in metadata
        }
      }
    }
  } catch {
    // No form
  }

  return { valid: errors.length === 0, fieldCount: count, errors };
}

export function extractFormDataMap(pdfDoc) {
  const data = {};
  try {
    const form = pdfDoc.getForm();
    for (const field of form.getFields()) {
      const name = field.getName();
      if (typeof field.getText === 'function') data[name] = field.getText() || '';
      else if (typeof field.isChecked === 'function') data[name] = field.isChecked();
      else if (typeof field.getSelected === 'function') data[name] = field.getSelected() || [];
    }
  } catch {
    // No form
  }
  return data;
}

export function exportFormAsXfdf(dataMap) {
  const fieldsXml = Object.entries(dataMap)
    .map(([k, v]) => `    <field name="${escapeXml(k)}"><value>${escapeXml(Array.isArray(v) ? v.join(',') : String(v))}</value></field>`)
    .join('\n');
  return `<?xml version="1.0" encoding="UTF-8"?>\n<xfdf xmlns="http://ns.adobe.com/xfdf/" xml:space="preserve">\n  <fields>\n${fieldsXml}\n  </fields>\n</xfdf>`;
}

export function exportFormAsFdf(dataMap) {
  const entries = Object.entries(dataMap)
    .map(([k, v]) => `<< /T (${String(k).replace(/[()\\]/g, '')}) /V (${String(Array.isArray(v) ? v.join(',') : v).replace(/[()\\]/g, '')}) >>`)
    .join('\n');
  return `%FDF-1.2\n1 0 obj\n<< /FDF << /Fields [\n${entries}\n] >> >>\nendobj\ntrailer\n<< /Root 1 0 R >>\n%%EOF`;
}

export function exportFormAsCsv(dataMap) {
  const keys = Object.keys(dataMap);
  const vals = keys.map((k) => `"${String(Array.isArray(dataMap[k]) ? dataMap[k].join(';') : dataMap[k]).replace(/"/g, '""')}"`);
  return `${keys.map((k) => `"${k.replace(/"/g, '""')}"`).join(',')}\n${vals.join(',')}`;
}

export function importFormDataIntoDoc(pdfDoc, rawText) {
  let parsedMap = {};
  const trimmed = rawText.trim();
  if (trimmed.startsWith('{')) {
    parsedMap = JSON.parse(trimmed);
  } else {
    // Parse XFDF <field name="..."> or FDF /T (...) /V (...)
    const xmlMatches = [...trimmed.matchAll(/<field[^>]*name="([^"]+)"[^>]*>\s*<value>([\s\S]*?)<\/value>/gi)];
    for (const m of xmlMatches) parsedMap[m[1]] = m[2];
    const fdfMatches = [...trimmed.matchAll(/\/T\s*\(([^)]*)\)\s*\/V\s*\(([^)]*)\)/g)];
    for (const m of fdfMatches) parsedMap[m[1]] = m[2];
  }

  const form = pdfDoc.getForm();
  for (const [key, val] of Object.entries(parsedMap)) {
    try {
      const f = form.getField(key);
      if (typeof f.setText === 'function') f.setText(String(val));
      else if (typeof f.check === 'function') {
        if (val === true || String(val).toLowerCase() === 'true') f.check();
        else f.uncheck();
      } else if (typeof f.select === 'function') {
        f.select(String(val));
      }
    } catch {
      // Field not found in target form
    }
  }
}

export async function flattenAcroForm(pdfDoc) {
  const form = pdfDoc.getForm();
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  form.updateFieldAppearances(font);
  form.flatten();
}

function escapeXml(str) {
  return String(str).replace(/[<>&'"]/g, (c) => ({
    '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;'
  }[c]));
}
