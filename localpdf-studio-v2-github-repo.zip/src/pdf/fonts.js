import { StandardFonts } from 'pdf-lib';

export const LOCAL_FONT_CATALOG = [
  { id: 'Helvetica', label: 'Helvetica (Standard)', url: null, standard: StandardFonts.Helvetica },
  { id: 'TimesRoman', label: 'Times Roman (Standard)', url: null, standard: StandardFonts.TimesRoman },
  { id: 'Courier', label: 'Courier Mono (Standard)', url: null, standard: StandardFonts.Courier },
  { id: 'Inter', label: 'Inter Regular (Offline TTF)', url: './fonts/Inter-Regular.ttf', standard: StandardFonts.Helvetica },
  { id: 'LiberationSans', label: 'Liberation Sans (Offline TTF)', url: './fonts/LiberationSans-Regular.ttf', standard: StandardFonts.Helvetica },
  { id: 'NotoSans', label: 'Noto Sans (Offline TTF)', url: './fonts/NotoSans-Regular.ttf', standard: StandardFonts.Helvetica },
  { id: 'DejaVuSans', label: 'DejaVu Sans (Offline TTF)', url: './fonts/DejaVuSans.ttf', standard: StandardFonts.Helvetica }
];

const cache = new Map();

export async function embedOfflineFont(pdfDoc, fontId) {
  const entry = LOCAL_FONT_CATALOG.find((f) => f.id === fontId) || LOCAL_FONT_CATALOG[0];
  if (entry.url) {
    try {
      if (!cache.has(entry.id)) {
        const res = await fetch(entry.url);
        const ct = res.headers.get('content-type') || '';
        if (res.ok && !ct.includes('text/html')) {
          cache.set(entry.id, new Uint8Array(await res.arrayBuffer()));
        }
      }
      const bytes = cache.get(entry.id);
      if (bytes) return await pdfDoc.embedFont(bytes, { subset: true });
    } catch {
      // Fallback to standard font
    }
  }
  return await pdfDoc.embedFont(entry.standard);
}
