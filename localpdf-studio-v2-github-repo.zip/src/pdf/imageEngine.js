import { pushGraphicsState, popGraphicsState, moveTo, lineTo, closePath, clip, evenOddClip, endPath } from 'pdf-lib';

export async function embedLocalImageAsset(pdfDoc, fileOrBlob, fileName = '') {
  const name = (fileOrBlob.name || fileName || '').toLowerCase();
  const type = (fileOrBlob.type || '').toLowerCase();
  const bytes = new Uint8Array(await fileOrBlob.arrayBuffer());
  if (type === 'image/jpeg' || name.endsWith('.jpg') || name.endsWith('.jpeg')) {
    const img = await pdfDoc.embedJpg(bytes);
    return { pdfImage: img, width: img.width, height: img.height };
  }
  if (type === 'image/png' || name.endsWith('.png')) {
    const img = await pdfDoc.embedPng(bytes);
    return { pdfImage: img, width: img.width, height: img.height };
  }
  const bmp = await createImageBitmap(fileOrBlob);
  const c = document.createElement('canvas');
  c.width = bmp.width; c.height = bmp.height;
  c.getContext('2d').drawImage(bmp, 0, 0);
  bmp.close();
  const pngBlob = await new Promise((r) => c.toBlob(r, 'image/png'));
  const img = await pdfDoc.embedPng(new Uint8Array(await pngBlob.arrayBuffer()));
  return { pdfImage: img, width: img.width, height: img.height };
}

export function calculateEffectiveDpi(pxW, pxH, widthPt, heightPt) {
  const minDpi = Math.min(pxW / Math.max(0.01, widthPt / 72), pxH / Math.max(0.01, heightPt / 72));
  return {
    minDpi: Math.round(minDpi),
    warning: minDpi < 150 ? `Low effective resolution (${Math.round(minDpi)} DPI). Recommend ≥ 150 DPI for crisp output.` : null
  };
}

export function drawImageWithClipping(page, pdfImage, targetRectPt, clipPolygonPt = null, evenOdd = false) {
  const { x, y, width, height } = targetRectPt;
  if (!clipPolygonPt || clipPolygonPt.length < 3) {
    page.drawImage(pdfImage, { x, y, width, height });
    return;
  }
  page.pushOperators(pushGraphicsState());
  page.pushOperators(moveTo(clipPolygonPt[0].x, clipPolygonPt[0].y));
  for (let i = 1; i < clipPolygonPt.length; i++) page.pushOperators(lineTo(clipPolygonPt[i].x, clipPolygonPt[i].y));
  page.pushOperators(closePath());
  page.pushOperators(evenOdd ? evenOddClip() : clip());
  page.pushOperators(endPath());
  page.drawImage(pdfImage, { x, y, width, height });
  page.pushOperators(popGraphicsState());
}
