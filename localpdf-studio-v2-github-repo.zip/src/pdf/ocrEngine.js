import { createWorker } from 'tesseract.js';
import { PDFDocument, rgb, StandardFonts, pushGraphicsState, popGraphicsState, setTextRenderingMode } from 'pdf-lib';

/**
 * 100% Offline OCR configuration pointing strictly to local relative paths under ./ocr/.
 * Never falls back to remote CDNs.
 */
export const OFFLINE_OCR_CONFIG = {
  workerPath: './ocr/worker.min.js',
  corePath: './ocr/tesseract-core.wasm.js',
  langPath: './ocr'
};

const installedPacks = new Map();

export async function installLocalTrainedDataFiles(fileList) {
  for (const file of fileList) {
    const buf = new Uint8Array(await file.arrayBuffer());
    installedPacks.set(file.name, buf);
  }
  return [...installedPacks.keys()];
}

/**
 * Renders a PDF page at target DPI (150–300), preprocesses in a Web Worker (grayscale + contrast),
 * runs offline Tesseract recognition, and embeds an invisible text layer (Tr = 3) aligned to page coords.
 */
export async function runOfflineOcrOnPage({
  pdfBytes,
  pdfjsPage,
  pageIndex,
  langs = 'eng',
  dpi = 200,
  preprocessWorkerFn,
  onStatus = () => {}
}) {
  const scale = Math.min(4.16, Math.max(1.5, dpi / 72));
  const viewport = pdfjsPage.getViewport({ scale });
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(viewport.width);
  canvas.height = Math.round(viewport.height);
  await pdfjsPage.render({ canvasContext: canvas.getContext('2d'), viewport }).promise;

  onStatus(`Preprocessing page ${pageIndex + 1} (${canvas.width}×${canvas.height}px @ ${dpi} DPI)...`);
  const bitmap = await createImageBitmap(canvas);
  const prepRes = await preprocessWorkerFn({
    bitmap,
    grayscale: true,
    contrastBoost: 1.25,
    mimeType: 'image/png'
  }, [bitmap]);

  const imageBlob = prepRes.ok
    ? new Blob([prepRes.buffer], { type: 'image/png' })
    : await new Promise((r) => canvas.toBlob(r, 'image/png'));

  onStatus(`Running offline Tesseract OCR (${langs}) on page ${pageIndex + 1}...`);
  const worker = await createWorker(langs, 1, OFFLINE_OCR_CONFIG);
  let words = [];
  let fullText = '';

  try {
    const { data } = await worker.recognize(imageBlob);
    words = data?.words || [];
    fullText = data?.text || '';
  } finally {
    await worker.terminate();
  }

  // Embed invisible text layer (text rendering mode Tr = 3) in pdf-lib
  const pdfDoc = await PDFDocument.load(pdfBytes);
  const page = pdfDoc.getPage(pageIndex);
  const { width: pageW, height: pageH } = page.getSize();
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);

  page.pushOperators(pushGraphicsState());
  page.pushOperators(setTextRenderingMode(3)); // Tr = 3: neither filled nor stroked (invisible selectable text)

  for (const w of words) {
    const cleanWord = (w.text || '').trim();
    if (!cleanWord || !w.bbox) continue;
    const { x0, y0, x1, y1 } = w.bbox;
    const boxW = Math.max(2, ((x1 - x0) / canvas.width) * pageW);
    const boxH = Math.max(4, ((y1 - y0) / canvas.height) * pageH);
    const pdfX = (x0 / canvas.width) * pageW;
    const pdfY = pageH - ((y1 / canvas.height) * pageH);
    const fontSize = Math.max(4, Math.min(72, boxH * 0.85));
    const measured = font.widthOfTextAtSize(cleanWord, fontSize);
    const fittedSize = measured > 0 ? Math.max(4, fontSize * Math.min(1, boxW / measured)) : fontSize;

    page.drawText(cleanWord, {
      x: pdfX,
      y: pdfY,
      size: fittedSize,
      font,
      color: rgb(0, 0, 0)
    });
  }

  page.pushOperators(popGraphicsState());
  const updatedPdfBytes = await pdfDoc.save({ useObjectStreams: true });
  return { updatedPdfBytes, text: fullText, wordCount: words.length };
}
