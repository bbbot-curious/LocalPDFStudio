import { rgb, degrees, PDFRawStream, decodePDFRawStream } from 'pdf-lib';
import { screenToPdfUserSpace, getPageBoxes } from './coordinates.js';
import { embedOfflineFont } from './fonts.js';

export function hexToRgbNormalized(hex = '#111827') {
  const clean = hex.replace('#', '').trim();
  const full = clean.length === 3 ? clean.split('').map((c) => c + c).join('') : clean.padEnd(6, '0');
  const num = parseInt(full, 16);
  return { r: ((num >> 16) & 255) / 255, g: ((num >> 8) & 255) / 255, b: (num & 255) / 255 };
}

export async function addTextRun(pdfDoc, pageIndex, options) {
  const { text, nx, ny, fontId = 'Helvetica', fontSize = 14, lineHeight = 1.25, colorHex = '#111827', rotationDeg = 0 } = options;
  if (!text || !text.trim()) return;
  const page = pdfDoc.getPage(pageIndex);
  const { mediaBox, cropBox, rotation: pageRotation } = getPageBoxes(page);
  const { x, y } = screenToPdfUserSpace({ nx, ny, mediaBox, cropBox, rotation: pageRotation });
  const font = await embedOfflineFont(pdfDoc, fontId);
  const { r, g, b } = hexToRgbNormalized(colorHex);
  const totalAngle = (rotationDeg + pageRotation) % 360;
  const rad = (totalAngle * Math.PI) / 180;
  const lineStep = fontSize * lineHeight;
  text.split(/\r?\n/).forEach((line, idx) => {
    page.drawText(line, {
      x: x + Math.sin(rad) * (idx * lineStep),
      y: y - Math.cos(rad) * (idx * lineStep),
      size: fontSize,
      font,
      color: rgb(r, g, b),
      rotate: degrees(totalAngle)
    });
  });
}

export function inspectPageTextOperators(pdfDoc, pageIndex) {
  const page = pdfDoc.getPage(pageIndex);
  const contents = page.node.Contents();
  if (!contents) return [];
  const streams = contents instanceof PDFRawStream ? [contents] : [];
  let text = '';
  for (const s of streams) {
    try { text += new TextDecoder('latin1').decode(decodePDFRawStream(s).decode()) + '\n'; } catch {}
  }
  return [...text.matchAll(/([^\r\n]*(?:Tj|TJ|Tf|Td|Tm)[^\r\n]*)/g)].map((m) => m[1].trim()).slice(0, 60);
}

export async function replaceTextRegion(pdfDoc, pageIndex, { rectPt, newText, fontId = 'Helvetica', fontSize = 12, textColorHex = '#111827', bgColorHex = '#FFFFFF' }) {
  const page = pdfDoc.getPage(pageIndex);
  const font = await embedOfflineFont(pdfDoc, fontId);
  const bg = hexToRgbNormalized(bgColorHex);
  const fg = hexToRgbNormalized(textColorHex);
  const boxW = Math.max(4, rectPt.x2 - rectPt.x1);
  const boxH = Math.max(4, rectPt.y2 - rectPt.y1);
  page.drawRectangle({ x: rectPt.x1, y: rectPt.y1, width: boxW, height: boxH, color: rgb(bg.r, bg.g, bg.b) });
  let effectiveSize = fontSize;
  const w = font.widthOfTextAtSize(newText, effectiveSize);
  if (w > boxW && w > 0) effectiveSize = Math.max(6, effectiveSize * (boxW / w));
  page.drawText(newText, { x: rectPt.x1 + 1, y: rectPt.y1 + Math.max(1, (boxH - effectiveSize) * 0.25), size: effectiveSize, font, color: rgb(fg.r, fg.g, fg.b) });
}
