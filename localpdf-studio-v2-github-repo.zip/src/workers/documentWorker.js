import { preflightPdfSecurity, auditPageTreeSafety } from '../pdf/securityGuard.js';
import {
  mergePdfBuffers,
  splitPdfBuffer,
  rotatePageWithoutRerender,
  extractSinglePagePdf,
  deepDuplicatePage
} from '../pdf/pageManager.js';
import { PDFDocument } from 'pdf-lib';

self.onmessage = async (event) => {
  const { id, task, payload } = event.data;

  try {
    if (payload?.pdfBytes) {
      const bytes = new Uint8Array(payload.pdfBytes);
      preflightPdfSecurity(bytes);
      const doc = await PDFDocument.load(bytes);
      auditPageTreeSafety(doc);
    }

    let resultData = null;
    if (task === 'merge') {
      const arrays = (payload.buffers || []).map((b) => new Uint8Array(b));
      const out = await mergePdfBuffers(arrays);
      resultData = { pdfBytes: out.buffer };
    } else if (task === 'split') {
      const chunks = await splitPdfBuffer(new Uint8Array(payload.pdfBytes), payload.mode, payload.options);
      resultData = {
        chunks: chunks.map((c) => ({ name: c.name, buffer: c.bytes.buffer }))
      };
    } else if (task === 'rotate') {
      const out = await rotatePageWithoutRerender(new Uint8Array(payload.pdfBytes), payload.pageIndex, payload.deltaDeg);
      resultData = { pdfBytes: out.buffer };
    } else if (task === 'extract') {
      const out = await extractSinglePagePdf(new Uint8Array(payload.pdfBytes), payload.pageIndex);
      resultData = { pdfBytes: out.buffer };
    } else if (task === 'duplicate') {
      const out = await deepDuplicatePage(new Uint8Array(payload.pdfBytes), payload.pageIndex);
      resultData = { pdfBytes: out.buffer };
    } else {
      throw new Error(`Unknown document worker task: ${task}`);
    }

    const transfer = [];
    if (resultData?.pdfBytes) transfer.push(resultData.pdfBytes);
    if (resultData?.chunks) resultData.chunks.forEach((c) => transfer.push(c.buffer));

    self.postMessage({ id, ok: true, data: resultData }, transfer);
  } catch (err) {
    self.postMessage({ id, ok: false, error: err.message });
  }
};
