self.onmessage = async (event) => {
  const {
    id,
    bitmap,
    cropNorm = { x: 0, y: 0, w: 1, h: 1 },
    scaleFactor = 1,
    grayscale = false,
    contrastBoost = 1,
    mimeType = 'image/png',
    quality = 0.92
  } = event.data;

  try {
    const sx = Math.max(0, Math.round(cropNorm.x * bitmap.width));
    const sy = Math.max(0, Math.round(cropNorm.y * bitmap.height));
    const sw = Math.max(1, Math.round(cropNorm.w * bitmap.width));
    const sh = Math.max(1, Math.round(cropNorm.h * bitmap.height));

    const outW = Math.max(1, Math.round(sw * scaleFactor));
    const outH = Math.max(1, Math.round(sh * scaleFactor));

    const canvas = new OffscreenCanvas(outW, outH);
    const ctx = canvas.getContext('2d');
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(bitmap, sx, sy, sw, sh, 0, 0, outW, outH);
    bitmap.close();

    if (grayscale || contrastBoost !== 1) {
      const imgData = ctx.getImageData(0, 0, outW, outH);
      const d = imgData.data;
      for (let i = 0; i < d.length; i += 4) {
        let r = d[i];
        let g = d[i + 1];
        let b = d[i + 2];
        if (grayscale) {
          const lum = 0.299 * r + 0.587 * g + 0.114 * b;
          r = g = b = lum;
        }
        if (contrastBoost !== 1) {
          r = Math.min(255, Math.max(0, ((r - 128) * contrastBoost) + 128));
          g = Math.min(255, Math.max(0, ((g - 128) * contrastBoost) + 128));
          b = Math.min(255, Math.max(0, ((b - 128) * contrastBoost) + 128));
        }
        d[i] = r;
        d[i + 1] = g;
        d[i + 2] = b;
      }
      ctx.putImageData(imgData, 0, 0);
    }

    const blob = await canvas.convertToBlob({ type: mimeType, quality });
    const buffer = await blob.arrayBuffer();
    self.postMessage({ id, ok: true, buffer, width: outW, height: outH, mimeType }, [buffer]);
  } catch (err) {
    self.postMessage({ id, ok: false, error: err.message });
  }
};
