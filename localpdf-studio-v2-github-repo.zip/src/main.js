import * as pdfjsLib from 'pdfjs-dist';
import pdfjsWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import { PDFDocument } from 'pdf-lib';
import JSZip from 'jszip';

import { LOCAL_FONT_CATALOG } from './pdf/fonts.js';
import { screenToPdfUserSpace, getPageBoxes } from './pdf/coordinates.js';
import { addTextRun, inspectPageTextOperators, replaceTextRegion } from './pdf/textEngine.js';
import { embedLocalImageAsset, calculateEffectiveDpi, drawImageWithClipping } from './pdf/imageEngine.js';
import { appendSpecCompliantAnnotation } from './pdf/annotationsEngine.js';
import { preflightPdfSecurity, auditPageTreeSafety, wipeLocalSessionStorage, SECURITY_LIMITS } from './pdf/securityGuard.js';
import { runBoundedBatch } from './pdf/pageManager.js';
import { applyTrueRedaction, verifyRedactedPage, scrubInfoAndXmpMetadata, stripHiddenOcgLayers } from './pdf/redactionEngine.js';
import {
  createAcroFormField,
  validateAcroFormFields,
  extractFormDataMap,
  exportFormAsXfdf,
  exportFormAsFdf,
  exportFormAsCsv,
  importFormDataIntoDoc,
  flattenAcroForm
} from './pdf/formsEngine.js';
import { installLocalTrainedDataFiles, runOfflineOcrOnPage } from './pdf/ocrEngine.js';

import DocumentWorker from './workers/documentWorker.js?worker';
import ImageWorker from './workers/imageWorker.js?worker';

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorkerUrl;

const state = {
  pdfBytes: null,
  fileName: 'document.pdf',
  currentPage: 0,
  zoom: 1,
  activeTab: 'organize',
  textReplaceMode: false,
  undoStack: [],
  redoStack: [],
  pendingImageFile: null,
  pendingImageMeta: null,
  batchFiles: [],
  batchCancelled: false,
  ocrPaused: false,
  ocrCancelled: false,
  dragStart: null,
  inkPointsNorm: []
};

let docWorker = new DocumentWorker();
const imageWorker = new ImageWorker();
let msgSeq = 0;
const pendingCallbacks = new Map();

function attachWorkerHandlers(worker) {
  worker.onmessage = (e) => {
    const cb = pendingCallbacks.get(e.data.id);
    if (cb) {
      pendingCallbacks.delete(e.data.id);
      cb(e.data);
    }
  };
}
attachWorkerHandlers(docWorker);
attachWorkerHandlers(imageWorker);

function callWorker(worker, payload, transfer = [], isDocumentWorker = false) {
  return new Promise((resolve, reject) => {
    const id = ++msgSeq;
    const timer = setTimeout(() => {
      pendingCallbacks.delete(id);
      if (isDocumentWorker) {
        docWorker.terminate();
        docWorker = new DocumentWorker();
        attachWorkerHandlers(docWorker);
      }
      reject(new Error('Worker operation timed out and was terminated safely.'));
    }, SECURITY_LIMITS.WORKER_TIMEOUT_MS);

    pendingCallbacks.set(id, (res) => {
      clearTimeout(timer);
      if (res.ok) resolve(res.data);
      else reject(new Error(res.error || 'Worker error'));
    });

    worker.postMessage({ id, ...payload }, transfer);
  });
}

// Populate font list
const fontSelect = document.getElementById('txt-font');
LOCAL_FONT_CATALOG.forEach((f) => {
  const opt = document.createElement('option');
  opt.value = f.id;
  opt.textContent = f.label;
  fontSelect.appendChild(opt);
});

function setTextSafe(elId, text) {
  const el = document.getElementById(elId);
  if (el) el.textContent = String(text ?? '');
}

function showSecurityNotice(msg) {
  const box = document.getElementById('security-alert');
  box.hidden = !msg;
  box.textContent = msg || '';
}

async function commitBytes(nextBytes) {
  if (!state.pdfBytes) return;
  state.undoStack.push(state.pdfBytes.slice());
  state.redoStack.length = 0;
  state.pdfBytes = nextBytes instanceof Uint8Array ? nextBytes : new Uint8Array(nextBytes);
  updateHistoryButtons();
  await reloadDocument();
}

async function commitMutation(fn) {
  if (!state.pdfBytes) return;
  const doc = await PDFDocument.load(state.pdfBytes);
  await fn(doc);
  const saved = await doc.save({ useObjectStreams: true });
  await commitBytes(saved);
}

function updateHistoryButtons() {
  document.getElementById('btn-undo').disabled = state.undoStack.length === 0;
  document.getElementById('btn-redo').disabled = state.redoStack.length === 0;
}

async function doUndo() {
  if (!state.undoStack.length) return;
  state.redoStack.push(state.pdfBytes.slice());
  state.pdfBytes = state.undoStack.pop();
  updateHistoryButtons();
  await reloadDocument();
}

async function doRedo() {
  if (!state.redoStack.length) return;
  state.undoStack.push(state.pdfBytes.slice());
  state.pdfBytes = state.redoStack.pop();
  updateHistoryButtons();
  await reloadDocument();
}

document.getElementById('btn-undo').addEventListener('click', doUndo);
document.getElementById('btn-redo').addEventListener('click', doRedo);

window.addEventListener('keydown', (e) => {
  const isMod = e.metaKey || e.ctrlKey;
  if (isMod && e.key.toLowerCase() === 'z' && !e.shiftKey) {
    e.preventDefault();
    doUndo();
  } else if ((isMod && e.key.toLowerCase() === 'y') || (isMod && e.shiftKey && e.key.toLowerCase() === 'z')) {
    e.preventDefault();
    doRedo();
  }
});

// Tabs
document.querySelectorAll('.tab-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    state.activeTab = btn.dataset.tab;
    document.querySelectorAll('.tab-pane').forEach((p) => {
      p.hidden = p.dataset.pane !== state.activeTab;
    });
  });
});

// Open & Merge PDFs
document.getElementById('btn-open').addEventListener('click', () => document.getElementById('file-open').click());
document.getElementById('file-open').addEventListener('change', async (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  try {
    const bytes = new Uint8Array(await file.arrayBuffer());
    const { isEncrypted } = preflightPdfSecurity(bytes);
    const checkDoc = await PDFDocument.load(bytes, { ignoreEncryption: true });
    auditPageTreeSafety(checkDoc);
    state.fileName = file.name;
    state.pdfBytes = bytes;
    state.undoStack.length = 0;
    state.redoStack.length = 0;
    state.currentPage = 0;
    updateHistoryButtons();
    showSecurityNotice(isEncrypted ? 'Note: Encrypted/restricted PDF detected; some operations may require an unlocked copy.' : '');
    await reloadDocument();
  } catch (err) {
    showSecurityNotice(`Security / Parse Guard: ${err.message}`);
  }
});

document.getElementById('btn-merge').addEventListener('click', () => document.getElementById('file-merge').click());
document.getElementById('file-merge').addEventListener('change', async (e) => {
  const files = [...(e.target.files || [])];
  if (!files.length || !state.pdfBytes) return;
  try {
    const extraBuffers = await Promise.all(files.map((f) => f.arrayBuffer()));
    const allBuffers = [state.pdfBytes.slice().buffer, ...extraBuffers];
    const res = await callWorker(docWorker, { task: 'merge', payload: { buffers: allBuffers } }, allBuffers, true);
    await commitBytes(res.pdfBytes);
  } catch (err) {
    showSecurityNotice(`Merge failed: ${err.message}`);
  }
});

document.getElementById('btn-wipe-session').addEventListener('click', async () => {
  state.pdfBytes = null;
  state.undoStack.length = 0;
  state.redoStack.length = 0;
  state.pendingImageFile = null;
  state.batchFiles = [];
  document.getElementById('page-stage').hidden = true;
  document.getElementById('thumb-list').innerHTML = '';
  document.getElementById('file-open').value = '';
  await wipeLocalSessionStorage();
  updateHistoryButtons();
  setTextSafe('coord-readout', 'Session cleared and local caches wiped.');
});

document.getElementById('btn-export').addEventListener('click', () => {
  if (!state.pdfBytes) return;
  const blob = new Blob([state.pdfBytes], { type: 'application/pdf' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = state.fileName.replace(/\.pdf$/i, '') + '-edited.pdf';
  a.click();
});

document.getElementById('zoom-select').addEventListener('change', async (e) => {
  state.zoom = parseFloat(e.target.value) || 1;
  await renderCurrentPage();
});

async function reloadDocument() {
  if (!state.pdfBytes) return;
  const pdf = await pdfjsLib.getDocument({ data: state.pdfBytes.slice() }).promise;
  if (state.currentPage >= pdf.numPages) state.currentPage = Math.max(0, pdf.numPages - 1);

  const hasDoc = pdf.numPages > 0;
  [
    'btn-merge', 'btn-export', 'btn-rot-left', 'btn-rot-right', 'btn-move-up', 'btn-move-down',
    'btn-dup-page', 'btn-extract-page', 'btn-del-page', 'btn-split-ranges', 'btn-split-every',
    'btn-split-bookmarks', 'btn-scan-ops', 'btn-verify-page', 'btn-validate-forms',
    'btn-flatten-forms', 'btn-export-json', 'btn-export-csv', 'btn-export-xfdf', 'btn-export-fdf',
    'btn-import-data', 'btn-ocr-page', 'btn-ocr-all', 'btn-export-pngs', 'btn-scrub-meta', 'btn-strip-ocg'
  ].forEach((id) => {
    document.getElementById(id).disabled = !hasDoc;
  });

  await renderThumbnails(pdf);
  await renderCurrentPage(pdf);
}

async function renderThumbnails(pdf) {
  const list = document.getElementById('thumb-list');
  list.innerHTML = '';
  for (let i = 0; i < pdf.numPages; i++) {
    const page = await pdf.getPage(i + 1);
    const vp = page.getViewport({ scale: 0.24 });
    const card = document.createElement('div');
    card.className = 'thumb-card' + (i === state.currentPage ? ' active' : '');
    const canvas = document.createElement('canvas');
    canvas.width = vp.width;
    canvas.height = vp.height;
    await page.render({ canvasContext: canvas.getContext('2d'), viewport: vp }).promise;

    const meta = document.createElement('div');
    meta.className = 'thumb-meta';
    const s1 = document.createElement('span'); s1.textContent = `Page ${i + 1}`;
    const s2 = document.createElement('span'); s2.textContent = `${page.rotate}°`;
    meta.append(s1, s2);
    card.append(canvas, meta);
    card.addEventListener('click', async () => {
      state.currentPage = i;
      await reloadDocument();
    });
    list.appendChild(card);
  }
}

async function renderCurrentPage(existingPdf = null) {
  if (!state.pdfBytes) return;
  const pdf = existingPdf || await pdfjsLib.getDocument({ data: state.pdfBytes.slice() }).promise;
  const page = await pdf.getPage(state.currentPage + 1);
  const vp = page.getViewport({ scale: state.zoom * 1.35 });

  const stage = document.getElementById('page-stage');
  const canvas = document.getElementById('pdf-canvas');
  const svg = document.getElementById('overlay-svg');
  stage.hidden = false;
  canvas.width = vp.width;
  canvas.height = vp.height;
  svg.setAttribute('viewBox', `0 0 ${vp.width} ${vp.height}`);
  svg.innerHTML = '';
  await page.render({ canvasContext: canvas.getContext('2d'), viewport: vp }).promise;
}

// Page ops via Document Worker
document.getElementById('btn-rot-left').addEventListener('click', async () => {
  const buf = state.pdfBytes.slice().buffer;
  const res = await callWorker(docWorker, { task: 'rotate', payload: { pdfBytes: buf, pageIndex: state.currentPage, deltaDeg: -90 } }, [buf], true);
  await commitBytes(res.pdfBytes);
});
document.getElementById('btn-rot-right').addEventListener('click', async () => {
  const buf = state.pdfBytes.slice().buffer;
  const res = await callWorker(docWorker, { task: 'rotate', payload: { pdfBytes: buf, pageIndex: state.currentPage, deltaDeg: 90 } }, [buf], true);
  await commitBytes(res.pdfBytes);
});
document.getElementById('btn-dup-page').addEventListener('click', async () => {
  const buf = state.pdfBytes.slice().buffer;
  const res = await callWorker(docWorker, { task: 'duplicate', payload: { pdfBytes: buf, pageIndex: state.currentPage } }, [buf], true);
  state.currentPage += 1;
  await commitBytes(res.pdfBytes);
});
document.getElementById('btn-extract-page').addEventListener('click', async () => {
  const buf = state.pdfBytes.slice().buffer;
  const res = await callWorker(docWorker, { task: 'extract', payload: { pdfBytes: buf, pageIndex: state.currentPage } }, [buf], true);
  const blob = new Blob([res.pdfBytes], { type: 'application/pdf' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `page-${state.currentPage + 1}-extracted.pdf`;
  a.click();
});
document.getElementById('btn-del-page').addEventListener('click', () =>
  commitMutation((doc) => {
    if (doc.getPageCount() > 1) doc.removePage(state.currentPage);
  })
);
document.getElementById('btn-move-up').addEventListener('click', () =>
  commitMutation(async (doc) => {
    if (state.currentPage === 0) return;
    const [p] = await doc.copyPages(doc, [state.currentPage]);
    doc.removePage(state.currentPage);
    doc.insertPage(state.currentPage - 1, p);
    state.currentPage -= 1;
  })
);
document.getElementById('btn-move-down').addEventListener('click', () =>
  commitMutation(async (doc) => {
    if (state.currentPage >= doc.getPageCount() - 1) return;
    const [p] = await doc.copyPages(doc, [state.currentPage]);
    doc.removePage(state.currentPage);
    doc.insertPage(state.currentPage + 1, p);
    state.currentPage += 1;
  })
);

// Split PDF
async function triggerSplit(mode) {
  const buf = state.pdfBytes.slice().buffer;
  const res = await callWorker(docWorker, {
    task: 'split',
    payload: {
      pdfBytes: buf,
      mode,
      options: {
        ranges: document.getElementById('split-ranges').value,
        everyN: parseInt(document.getElementById('split-every-n').value, 10) || 2
      }
    }
  }, [buf], true);

  const zip = new JSZip();
  for (const c of res.chunks) zip.file(c.name, c.buffer);
  const zipBlob = await zip.generateAsync({ type: 'blob' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(zipBlob);
  a.download = 'split-pdfs.zip';
  a.click();
}
document.getElementById('btn-split-ranges').addEventListener('click', () => triggerSplit('ranges'));
document.getElementById('btn-split-every').addEventListener('click', () => triggerSplit('everyN'));
document.getElementById('btn-split-bookmarks').addEventListener('click', () => triggerSplit('bookmarks'));

// Batch operations
document.getElementById('btn-pick-batch').addEventListener('click', () => document.getElementById('batch-files').click());
document.getElementById('batch-files').addEventListener('change', (e) => {
  state.batchFiles = [...(e.target.files || [])];
  document.getElementById('btn-run-batch').disabled = state.batchFiles.length === 0;
  setTextSafe('batch-log', `${state.batchFiles.length} PDF(s) queued.`);
});

document.getElementById('btn-run-batch').addEventListener('click', async () => {
  state.batchCancelled = false;
  document.getElementById('btn-cancel-batch').disabled = false;
  const action = document.getElementById('batch-action').value;
  const watermarkText = document.getElementById('batch-watermark-text').value;
  const logLines = [];

  const { results, cancelled } = await runBoundedBatch(
    state.batchFiles,
    action,
    { watermarkText },
    {
      concurrency: 2,
      shouldCancel: () => state.batchCancelled,
      onProgress: (p) => {
        setTextSafe('batch-log', `[${p.index + 1}/${p.total}] ${p.fileName}: ${p.status}${p.error ? ' (' + p.error + ')' : ''}`);
      }
    }
  );

  const zip = new JSZip();
  for (const r of results) {
    if (r.status === 'done') {
      zip.file(r.fileName.replace(/\.pdf$/i, '') + '-batch.pdf', r.bytes);
      logLines.push(`OK: ${r.fileName}`);
    } else {
      logLines.push(`ERR: ${r.fileName} — ${r.error}`);
    }
  }
  if (cancelled) logLines.push('Batch cancelled by user.');

  const zipBlob = await zip.generateAsync({ type: 'blob' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(zipBlob);
  a.download = 'batch-output.zip';
  a.click();
  document.getElementById('btn-cancel-batch').disabled = true;
  setTextSafe('batch-log', logLines.join('\n'));
});

document.getElementById('btn-cancel-batch').addEventListener('click', () => {
  state.batchCancelled = true;
});

// Text operators & replace toggle
document.getElementById('btn-mode-replace').addEventListener('click', (e) => {
  state.textReplaceMode = !state.textReplaceMode;
  e.target.classList.toggle('active', state.textReplaceMode);
});

document.getElementById('btn-scan-ops').addEventListener('click', async () => {
  const doc = await PDFDocument.load(state.pdfBytes);
  const ops = inspectPageTextOperators(doc, state.currentPage);
  setTextSafe('op-list', ops.length ? ops.join('\n') : 'No uncompressed stream operators found.');
});

// Image selection
document.getElementById('img-file').addEventListener('change', async (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  state.pendingImageFile = file;
  const bmp = await createImageBitmap(file);
  state.pendingImageMeta = { width: bmp.width, height: bmp.height, type: file.type };
  bmp.close();
  setTextSafe('img-info', `${file.name} (${state.pendingImageMeta.width}×${state.pendingImageMeta.height}px)`);
});

// Canvas interactions: Text, Image, True Redaction, AcroForms, Annotations
const svgOverlay = document.getElementById('overlay-svg');
function getNormPt(evt) {
  const rect = svgOverlay.getBoundingClientRect();
  return {
    nx: Math.max(0, Math.min(1, (evt.clientX - rect.left) / rect.width)),
    ny: Math.max(0, Math.min(1, (evt.clientY - rect.top) / rect.height)),
    px: evt.clientX - rect.left,
    py: evt.clientY - rect.top
  };
}

svgOverlay.addEventListener('pointerdown', (e) => {
  if (!state.pdfBytes) return;
  const pt = getNormPt(e);
  state.dragStart = pt;
  state.inkPointsNorm = [pt];
  svgOverlay.setPointerCapture(e.pointerId);
});

svgOverlay.addEventListener('pointermove', (e) => {
  if (!state.pdfBytes) return;
  const pt = getNormPt(e);
  setTextSafe('coord-readout', `Page ${state.currentPage + 1} • (${pt.nx.toFixed(3)}, ${pt.ny.toFixed(3)})`);
  if (!state.dragStart) return;
  const subtype = document.getElementById('annot-subtype').value;
  if (state.activeTab === 'annot' && (subtype === 'Ink' || subtype === 'PolyLine')) {
    state.inkPointsNorm.push(pt);
    const d = state.inkPointsNorm.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.px} ${p.py}`).join(' ');
    svgOverlay.innerHTML = `<path d="${d}" fill="none" stroke="#38bdf8" stroke-width="2" />`;
  } else {
    const x = Math.min(state.dragStart.px, pt.px);
    const y = Math.min(state.dragStart.py, pt.py);
    const w = Math.abs(pt.px - state.dragStart.px);
    const h = Math.abs(pt.py - state.dragStart.py);
    svgOverlay.innerHTML = `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="rgba(56,189,248,0.18)" stroke="#38bdf8" stroke-dasharray="4 2" stroke-width="1.5" />`;
  }
});

svgOverlay.addEventListener('pointerup', async (e) => {
  if (!state.dragStart || !state.pdfBytes) return;
  const endPt = getNormPt(e);
  const startPt = state.dragStart;
  state.dragStart = null;
  svgOverlay.innerHTML = '';
  const isClick = Math.hypot(endPt.px - startPt.px, endPt.py - startPt.py) < 6;

  if (state.activeTab === 'text') {
    if (state.textReplaceMode && !isClick) {
      await commitMutation(async (doc) => {
        const page = doc.getPage(state.currentPage);
        const { mediaBox, cropBox, rotation } = getPageBoxes(page);
        const rectPt = screenRectToPdfRect({ nx1: startPt.nx, ny1: startPt.ny, nx2: endPt.nx, ny2: endPt.ny, mediaBox, cropBox, rotation });
        await replaceTextRegion(doc, state.currentPage, {
          rectPt,
          newText: document.getElementById('txt-replace-val').value || '',
          fontId: document.getElementById('txt-font').value,
          fontSize: parseFloat(document.getElementById('txt-size').value) || 12,
          textColorHex: document.getElementById('txt-color').value,
          bgColorHex: document.getElementById('txt-bg-color').value
        });
      });
    } else {
      await commitMutation(async (doc) => {
        await addTextRun(doc, state.currentPage, {
          text: document.getElementById('txt-content').value,
          nx: startPt.nx, ny: startPt.ny,
          fontId: document.getElementById('txt-font').value,
          fontSize: parseFloat(document.getElementById('txt-size').value) || 14,
          lineHeight: parseFloat(document.getElementById('txt-lineheight').value) || 1.25,
          colorHex: document.getElementById('txt-color').value,
          rotationDeg: parseFloat(document.getElementById('txt-rotate').value) || 0
        });
      });
    }
    return;
  }

  if (state.activeTab === 'image' && state.pendingImageFile && !isClick) {
    const [cx, cy] = document.getElementById('img-crop-xy').value.split(',').map((v) => parseFloat(v) || 0);
    const [cw, ch] = document.getElementById('img-crop-wh').value.split(',').map((v) => parseFloat(v) || 1);
    const scaleFactor = parseFloat(document.getElementById('img-scale').value) || 1;
    const clipMode = document.getElementById('img-clip-mode').value;

    let fileToEmbed = state.pendingImageFile;
    let pxW = state.pendingImageMeta.width;
    let pxH = state.pendingImageMeta.height;

    if (cx !== 0 || cy !== 0 || cw !== 1 || ch !== 1 || scaleFactor < 1) {
      const bmp = await createImageBitmap(state.pendingImageFile);
      const wr = await callWorker(imageWorker, { bitmap, cropNorm: { x: cx, y: cy, w: cw, h: ch }, scaleFactor, mimeType: 'image/png' }, [bitmap], false);
      fileToEmbed = new Blob([wr.buffer], { type: 'image/png' });
      pxW = wr.width; pxH = wr.height;
    }

    await commitMutation(async (doc) => {
      const page = doc.getPage(state.currentPage);
      const { mediaBox, cropBox, rotation } = getPageBoxes(page);
      const rectPt = screenRectToPdfRect({ nx1: startPt.nx, ny1: startPt.ny, nx2: endPt.nx, ny2: endPt.ny, mediaBox, cropBox, rotation });
      const dpiInfo = calculateEffectiveDpi(pxW, pxH, rectPt.width, rectPt.height);
      const warnEl = document.getElementById('dpi-warning');
      warnEl.hidden = !dpiInfo.warning;
      warnEl.textContent = dpiInfo.warning || '';

      const emb = await embedLocalImageAsset(doc, fileToEmbed, state.pendingImageFile.name);
      let clipPoly = null;
      if (clipMode === 'rect') clipPoly = [{ x: rectPt.x1, y: rectPt.y1 }, { x: rectPt.x2, y: rectPt.y1 }, { x: rectPt.x2, y: rectPt.y2 }, { x: rectPt.x1, y: rectPt.y2 }];
      else if (clipMode === 'diamond') {
        const mx = (rectPt.x1 + rectPt.x2) / 2, my = (rectPt.y1 + rectPt.y2) / 2;
        clipPoly = [{ x: mx, y: rectPt.y1 }, { x: rectPt.x2, y: my }, { x: mx, y: rectPt.y2 }, { x: rectPt.x1, y: my }];
      }
      drawImageWithClipping(page, emb.pdfImage, { x: rectPt.x1, y: rectPt.y1, width: rectPt.width, height: rectPt.height }, clipPoly);
    });
    return;
  }

  if (state.activeTab === 'redact' && !isClick) {
    const redactedBytes = await applyTrueRedaction(state.pdfBytes, state.currentPage, {
      nx1: startPt.nx, ny1: startPt.ny, nx2: endPt.nx, ny2: endPt.ny,
      fillHex: document.getElementById('redact-fill').value,
      scrubMetadata: document.getElementById('redact-scrub-meta').checked,
      stripOcg: document.getElementById('redact-strip-ocg').checked
    });
    await commitBytes(redactedBytes);
    await runVerificationGate();
    return;
  }

  if (state.activeTab === 'forms' && !isClick) {
    await commitMutation(async (doc) => {
      await createAcroFormField(doc, state.currentPage, {
        fieldType: document.getElementById('form-field-type').value,
        name: document.getElementById('form-field-name').value || `field_${Date.now()}`,
        value: document.getElementById('form-field-value').value,
        options: document.getElementById('form-field-options').value.split(',').map((s) => s.trim()).filter(Boolean),
        required: document.getElementById('form-field-req').checked,
        readOnly: document.getElementById('form-field-ro').checked,
        regexPattern: document.getElementById('form-field-regex').value,
        rectNorm: { nx1: startPt.nx, ny1: startPt.ny, nx2: endPt.nx, ny2: endPt.ny }
      });
    });
    return;
  }

  if (state.activeTab === 'annot') {
    const raw = document.getElementById('annot-subtype').value;
    const isArrow = raw === 'Arrow';
    const subtype = isArrow ? 'Line' : raw;
    await commitMutation((doc) => {
      const page = doc.getPage(state.currentPage);
      const { mediaBox, cropBox, rotation } = getPageBoxes(page);
      const normPts = (subtype === 'Ink' || subtype === 'PolyLine') && state.inkPointsNorm.length >= 2
        ? state.inkPointsNorm
        : [startPt, isClick ? { nx: Math.min(1, startPt.nx + 0.05), ny: Math.min(1, startPt.ny + 0.05) } : endPt];
      const pts = normPts.map((p) => screenToPdfUserSpace({ nx: p.nx, ny: p.ny, mediaBox, cropBox, rotation }));
      const xs = pts.map((p) => p.x), ys = pts.map((p) => p.y), pad = 4;
      appendSpecCompliantAnnotation(doc, state.currentPage, {
        subtype,
        rect: { x1: Math.min(...xs) - pad, y1: Math.min(...ys) - pad, x2: Math.max(...xs) + pad, y2: Math.max(...ys) + pad },
        contents: document.getElementById('annot-contents').value || '',
        colorHex: document.getElementById('annot-color').value,
        strokeWidth: parseFloat(document.getElementById('annot-width').value) || 2,
        arrowHead: isArrow,
        pointsPt: pts,
        stampLabel: (document.getElementById('annot-contents').value || 'REVIEWED').toUpperCase()
      });
    });
  }
});

// Verification Gate
async function runVerificationGate() {
  if (!state.pdfBytes) return;
  const box = document.getElementById('redact-verify-box');
  const vCanvas = document.getElementById('verify-canvas');
  box.hidden = false;
  const report = await verifyRedactedPage(state.pdfBytes, state.currentPage, vCanvas);
  setTextSafe('verify-text-report', `Remaining text tokens on page ${state.currentPage + 1}: ${report.totalTextItemsRemaining}\nSample: ${report.sampleText}`);
}
document.getElementById('btn-verify-page').addEventListener('click', runVerificationGate);
document.getElementById('btn-close-verify').addEventListener('click', () => {
  document.getElementById('redact-verify-box').hidden = true;
});

// Forms actions
document.getElementById('btn-validate-forms').addEventListener('click', async () => {
  const doc = await PDFDocument.load(state.pdfBytes);
  const res = validateAcroFormFields(doc);
  setTextSafe('form-validation-out', res.valid
    ? `Valid (${res.fieldCount} field(s) checked, 0 errors).`
    : `Validation Errors (${res.errors.length}):\n` + res.errors.join('\n'));
});

document.getElementById('btn-flatten-forms').addEventListener('click', () =>
  commitMutation(async (doc) => {
    const val = validateAcroFormFields(doc);
    if (!val.valid) {
      setTextSafe('form-validation-out', 'Fix validation errors before flattening:\n' + val.errors.join('\n'));
      return;
    }
    await flattenAcroForm(doc);
    setTextSafe('form-validation-out', 'Form fields flattened into static page content.');
  })
);

function downloadTextFile(filename, content, mime) {
  const blob = new Blob([content], { type: mime });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
}

document.getElementById('btn-export-json').addEventListener('click', async () => {
  const doc = await PDFDocument.load(state.pdfBytes);
  downloadTextFile('form-data.json', JSON.stringify(extractFormDataMap(doc), null, 2), 'application/json');
});
document.getElementById('btn-export-csv').addEventListener('click', async () => {
  const doc = await PDFDocument.load(state.pdfBytes);
  downloadTextFile('form-data.csv', exportFormAsCsv(extractFormDataMap(doc)), 'text/csv');
});
document.getElementById('btn-export-xfdf').addEventListener('click', async () => {
  const doc = await PDFDocument.load(state.pdfBytes);
  downloadTextFile('form-data.xfdf', exportFormAsXfdf(extractFormDataMap(doc)), 'application/vnd.adobe.xfdf');
});
document.getElementById('btn-export-fdf').addEventListener('click', async () => {
  const doc = await PDFDocument.load(state.pdfBytes);
  downloadTextFile('form-data.fdf', exportFormAsFdf(extractFormDataMap(doc)), 'application/vnd.fdf');
});

document.getElementById('btn-import-data').addEventListener('click', () => document.getElementById('form-import-file').click());
document.getElementById('form-import-file').addEventListener('change', async (e) => {
  const file = e.target.files?.[0];
  if (!file || !state.pdfBytes) return;
  const text = await file.text();
  await commitMutation((doc) => importFormDataIntoDoc(doc, text));
  setTextSafe('form-validation-out', `Imported data from ${file.name}.`);
});

// Offline OCR
document.getElementById('btn-install-traineddata').addEventListener('click', () => document.getElementById('ocr-lang-file').click());
document.getElementById('ocr-lang-file').addEventListener('change', async (e) => {
  const files = [...(e.target.files || [])];
  if (!files.length) return;
  const installed = await installLocalTrainedDataFiles(files);
  setTextSafe('ocr-progress', `Loaded local packs: ${installed.join(', ')}`);
});

async function executeOcrRange(pageIndices) {
  state.ocrCancelled = false;
  state.ocrPaused = false;
  document.getElementById('btn-ocr-pause').disabled = false;
  document.getElementById('btn-ocr-cancel').disabled = false;

  const langs = document.getElementById('ocr-langs').value || 'eng';
  const dpi = parseInt(document.getElementById('ocr-dpi').value, 10) || 200;
  let allRecognized = [];

  for (let idx = 0; idx < pageIndices.length; idx++) {
    if (state.ocrCancelled) break;
    while (state.ocrPaused && !state.ocrCancelled) {
      await new Promise((r) => setTimeout(r, 200));
    }
    const pIdx = pageIndices[idx];
    const pct = Math.round(((idx + 1) / pageIndices.length) * 100);
    setTextSafe('ocr-progress', `Page ${pIdx + 1} (${idx + 1}/${pageIndices.length} — ${pct}%)`);

    const pdf = await pdfjsLib.getDocument({ data: state.pdfBytes.slice() }).promise;
    const pdfjsPage = await pdf.getPage(pIdx + 1);

    try {
      const res = await runOfflineOcrOnPage({
        pdfBytes: state.pdfBytes,
        pdfjsPage,
        pageIndex: pIdx,
        langs,
        dpi,
        preprocessWorkerFn: (payload, transfer) => callWorker(imageWorker, payload, transfer, false),
        onStatus: (msg) => setTextSafe('ocr-progress', `${msg} (${pct}%)`)
      });
      await commitBytes(res.updatedPdfBytes);
      allRecognized.push(`--- Page ${pIdx + 1} (${res.wordCount} words) ---\n${res.text}`);
    } catch (err) {
      setTextSafe('ocr-progress', `OCR error on page ${pIdx + 1}: ${err.message}`);
      break;
    }
  }

  document.getElementById('btn-ocr-pause').disabled = true;
  document.getElementById('btn-ocr-cancel').disabled = true;
  setTextSafe('ocr-preview', allRecognized.join('\n') || 'No text recognized.');
}

document.getElementById('btn-ocr-page').addEventListener('click', () => executeOcrRange([state.currentPage]));
document.getElementById('btn-ocr-all').addEventListener('click', async () => {
  const pdf = await pdfjsLib.getDocument({ data: state.pdfBytes.slice() }).promise;
  executeOcrRange(Array.from({ length: pdf.numPages }, (_, i) => i));
});
document.getElementById('btn-ocr-pause').addEventListener('click', (e) => {
  state.ocrPaused = !state.ocrPaused;
  e.target.textContent = state.ocrPaused ? 'Resume' : 'Pause';
});
document.getElementById('btn-ocr-cancel').addEventListener('click', () => {
  state.ocrCancelled = true;
});

// Export & Security
document.getElementById('btn-export-pngs').addEventListener('click', async () => {
  const pdf = await pdfjsLib.getDocument({ data: state.pdfBytes.slice() }).promise;
  const zip = new JSZip();
  for (let i = 1; i <= pdf.numPages; i++) {
    const p = await pdf.getPage(i);
    const vp = p.getViewport({ scale: 2 });
    const c = document.createElement('canvas');
    c.width = vp.width; c.height = vp.height;
    await p.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise;
    zip.file(`page-${String(i).padStart(3, '0')}.png`, await new Promise((r) => c.toBlob(r, 'image/png')));
  }
  const blob = await zip.generateAsync({ type: 'blob' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'pages-export.zip';
  a.click();
});

document.getElementById('btn-scrub-meta').addEventListener('click', () =>
  commitMutation((doc) => {
    scrubInfoAndXmpMetadata(doc);
    setTextSafe('meta-status', 'Info & XMP metadata scrubbed.');
  })
);

document.getElementById('btn-strip-ocg').addEventListener('click', () =>
  commitMutation((doc) => {
    stripHiddenOcgLayers(doc);
    setTextSafe('meta-status', 'Hidden /OCProperties layers removed.');
  })
);
